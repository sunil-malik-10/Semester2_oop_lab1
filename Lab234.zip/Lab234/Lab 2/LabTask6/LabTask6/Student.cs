﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabTask6
{
    internal class Student
    {
        public Student(string Name) {

            name = Name;
        }

        public string name;
    }
}
