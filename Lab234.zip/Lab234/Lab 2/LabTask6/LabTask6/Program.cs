﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabTask6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student std1 = new Student("Talha");
            Student std2 = new Student("Saad");
            Console.WriteLine(std1.name);
            Console.WriteLine(std2.name);
            Console.Read();
        }
    }
}
