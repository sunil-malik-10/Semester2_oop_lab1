﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabTask2
{
    internal class Student
    {
        public string name;
        public float matricMarks;
        public float fscMarks;
        public float ecatMarks;
    }
}
