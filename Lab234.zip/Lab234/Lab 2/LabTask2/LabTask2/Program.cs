﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabTask2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int size = 5;
            Student[] studentsData = new Student[size];
            for(int i = 0; i < size; i++)
            {
                Console.WriteLine("Student " + (i+1) + " Data");
                studentsData[i] = TakeInput();
                Console.Clear();
            }
            printStudents(studentsData, size);
            Console.Read();
        }
        static Student TakeInput()
        {
            Student std = new Student();

            Console.Write("Enter Name: ");
            std.name = Console.ReadLine();

            Console.Write("Enter Matric Marks: ");
            std.matricMarks = float.Parse(Console.ReadLine());

            Console.Write("Enter Fsc Marks: ");
            std.fscMarks = float.Parse(Console.ReadLine());

            Console.Write("Enter Ecat Marks: ");
            std.ecatMarks = float.Parse(Console.ReadLine());

            return std;
        }
        static void printStudents(Student[] studentsData,int size)
        {
            Console.WriteLine(" Name \t Matric Marks\t Fsc Marks\t EcatMarks");
            for(int i = 0; i <size; i++)
            {
                Console.WriteLine(studentsData[i].name +"\t "+ studentsData[i].matricMarks + "\t\t" + studentsData[i].fscMarks + "\t\t" + studentsData[i].ecatMarks);
            }
        }
    }
}
