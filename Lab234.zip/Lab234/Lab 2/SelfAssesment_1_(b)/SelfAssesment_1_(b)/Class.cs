﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SelfAssesment_1__b_
{
    internal class Class
    {
        public string name;
        public int age;
        public string education;
        public float hight;
    }
}
