﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SelfAssesment_1__b_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Class person1 = new Class();
            Class person2 = new Class();

            Console.WriteLine(person1.name);
            Console.WriteLine(person1.age);
            Console.WriteLine(person1.education);
            Console.WriteLine(person1.hight);

            Console.WriteLine(person2.name);
            Console.WriteLine(person2.age);
            Console.WriteLine(person2.education);
            Console.WriteLine(person2.hight);

            Console.Read();
        }
    }
}
