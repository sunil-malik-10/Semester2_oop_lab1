﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SelfAssesment_Task1_a
{
    internal class Student
    {
        public Student(string Name, float MatricMarks, float Fscmarks, float EcatMarks)
        {

            name = Name;
            matricMarks = MatricMarks;
            fscMarks = Fscmarks;
            ecatMarks = EcatMarks;
        }
        public string name;
        public float matricMarks;
        public float fscMarks;
        public float ecatMarks;
    }
}
