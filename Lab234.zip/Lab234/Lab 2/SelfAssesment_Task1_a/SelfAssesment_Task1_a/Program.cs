﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SelfAssesment_Task1_a
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student std1 = new Student("Talha", 1086, 955, 233);
            Student std2 = new Student("Saad", 0.06, 0.09F, 100.2F);
            Console.WriteLine(std1.name + "\t" + std1.matricMarks + "\t" + std1.fscMarks + "\t" + std1.ecatMarks);
            Console.WriteLine(std2.name + "\t" + std2.matricMarks + "\t" + std2.fscMarks + "\t" + std2.ecatMarks);
            Console.Read();
        }
    }
}
