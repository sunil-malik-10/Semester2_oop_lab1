﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagementSysytem
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int index = 0;
            int size = 3;
            Student[] arr_students = new Student[size];

            
            while (true)
            {
                Header();
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.WriteLine("What do you want to do: ");
                Console.WriteLine("1.Add Student  \n2.Show Students  \n3.Calculate Aggregate  \n4.Top Students  \n5.Exit");
                int option = Convert.ToInt32(Console.ReadLine());
                if(option == 1)
                {
                    AddStudents(arr_students, ref index);
                }
                else if(option == 2)
                {
                    ShowStudents(arr_students, size);
                }
                else if(option == 3)
                {
                    ShowAllAggregates(size, arr_students);
                }
                else if(option == 4)
                {
                    TopStudents(arr_students, size);
                }
                else if(option == 5)
                {
                    break;
                }
                Console.Clear();
            }
            
        }
        static void AddStudents(Student[] std,ref int index)
        {
            Console.Clear();
            Header();
            int number;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("How many Students you want to add: ");
            number = Convert.ToInt32(Console.ReadLine());

            string name;
            float matric, fsc, ecat;

            for(int i = 0; i < number; i++)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("Student " + (i + 1));
                Console.Write("Enter Name: ");
                name = Console.ReadLine();

                Console.Write("Enter Matric Marks: ");
                matric = float.Parse(Console.ReadLine());

                Console.Write("Enter Fsc Marks: ");
                fsc = float.Parse(Console.ReadLine());

                Console.Write("Enter Ecat Marks: ");
                ecat = float.Parse(Console.ReadLine());
                std[index] = new Student(name, matric, fsc, ecat);
                index++;
                Console.Clear();
                Header();
            }
            Console.WriteLine("Added Successfully");
        }
        static float aggregateCalculator(Student std)
        {
            float aggr = 0;
            aggr = (((std.matricMarks/1100)*0.25F)  + ((std.fscMarks/520)*0.45F) + ((std.ecatMarks/4)*0.3F))*100;
            return aggr;
        }
        static void ShowAllAggregates(int size, Student[] arr)
        {
            Console.Clear();
            Header();
            Console.WriteLine("Name \t Aggregate");
            for(int i = 0; i < size; i++)
            {
                if (arr[i] != null)
                {
                    Console.WriteLine(arr[i].name + "\t" + aggregateCalculator(arr[i]));
                }
                
            }
            Console.ReadLine();
        }
        static void ShowStudents(Student[] studentsData, int size)
        {
            Console.Clear();
            Header();
            Console.WriteLine(" Name \t Matric Marks\t Fsc Marks\t EcatMarks");
            for (int i = 0; i < size; i++)
            {
                if (studentsData[i] != null)
                {
                    Console.WriteLine(studentsData[i].name + "\t " + studentsData[i].matricMarks + "\t\t" + studentsData[i].fscMarks + "\t\t" + studentsData[i].ecatMarks);
                }
            }
            Console.ReadLine();
        }
        static void TopStudents(Student[] std,int size)
        {
            float[] cloneArr = new float[size];
            for(int i = 0; i< size; i++)
            {
                if (std[i] != null)
                {
                    cloneArr[i] = aggregateCalculator(std[i]);
                }
                
            }
            Array.Sort(cloneArr);
            Array.Reverse(cloneArr);
            Console.Clear();Header();
            Console.WriteLine("                         Top Students");
            Console.Write("First : " + cloneArr[0] + "\nSecond: " + cloneArr[1] + "\nThird: " + cloneArr[2]);
            Console.ReadKey();
                
        }
        static void Header()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(@"  
          _____  _               _               _     __  __                                                            _   
         / ____|| |             | |             | |   |  \/  |                                                          | |  
        | (___  | |_  _   _   __| |  ___  _ __  | |_  | \  / |  __ _  _ __    __ _   __ _   ___  _ __ ___    ___  _ __  | |_ 
         \___ \ | __|| | | | / _` | / _ \| '_ \ | __| | |\/| | / _` || '_ \  / _` | / _` | / _ \| '_ ` _ \  / _ \| '_ \ | __|
         ____) || |_ | |_| || (_| ||  __/| | | || |_  | |  | || (_| || | | || (_| || (_| ||  __/| | | | | ||  __/| | | || |_ 
        |_____/  \__| \__,_| \__,_| \___||_| |_| \__| |_|  |_| \__,_||_| |_| \__,_| \__, | \___||_| |_| |_| \___||_| |_| \__|
                                                                                     __/ |                                   
                                                                                    |___/                                    
________________________________________________________________________________________________________________________________________________________________________");

            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}
