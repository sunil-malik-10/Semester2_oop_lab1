﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagementSysytem
{
    internal class Student
    {
        public Student(string Name,float Matric,float Fsc,float Ecat) 
        { 
            name = Name;
            matricMarks = Matric;
            fscMarks = Fsc;
            ecatMarks = Ecat;
        }

        public string name;
        public float matricMarks;
        public float fscMarks;
        public float ecatMarks;
    }
}
