﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SelfAssesment_Task1_b
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student std1 = new Student("Ali", 1086, 955, 233);
            Student std3 = new Student("Inshalla", 1082, 155, 133);
            Student std4 = new Student("Anas", 900,1010, 273);
            Student std2 = new Student("Bilal", 0.06F, 0.09F, 100.2F);
            Console.WriteLine(std1.name + "\t" + std1.matricMarks + "\t" + std1.fscMarks + "\t" + std1.ecatMarks);
            Console.WriteLine(std2.name + "\t" + std2.matricMarks + "\t" + std2.fscMarks + "\t" + std2.ecatMarks);
            Console.WriteLine(std3.name + "\t" + std3.matricMarks + "\t" + std3.fscMarks + "\t" + std3.ecatMarks);
            Console.WriteLine(std4.name + "\t" + std4.matricMarks + "\t" + std4.fscMarks + "\t" + std4.ecatMarks);
            Console.Read();
        }
    }
}
