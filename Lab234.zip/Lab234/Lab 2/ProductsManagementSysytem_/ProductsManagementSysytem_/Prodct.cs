﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductsManagementSysytem_
{
    internal class Prodct
    {
        public Prodct(string Name,string Category,string Brand,string Country,float Price,int id) 
        { 
            name = Name;
            category = Category;
            brand = Brand;
            country = Country;
            price = Price;
            ID = id;
        }
        public int ID;
        public float price;
        public string name;
        public string country;
        public string brand;
        public string category;
    }
}
