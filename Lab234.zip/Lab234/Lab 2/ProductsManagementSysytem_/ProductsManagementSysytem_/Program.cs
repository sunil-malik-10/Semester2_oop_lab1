﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductsManagementSysytem_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
        static void Header()
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine(@" 
         _____                    _               _     __  __                                                            _   
        |  __ \                  | |             | |   |  \/  |                                                          | |  
        | |__) | _ __   ___    __| | _   _   ___ | |_  | \  / |  __ _  _ __    __ _   __ _   ___  _ __ ___    ___  _ __  | |_ 
        |  ___/ | '__| / _ \  / _` || | | | / __|| __| | |\/| | / _` || '_ \  / _` | / _` | / _ \| '_ ` _ \  / _ \| '_ \ | __|
        | |     | |   | (_) || (_| || |_| || (__ | |_  | |  | || (_| || | | || (_| || (_| ||  __/| | | | | ||  __/| | | || |_ 
        |_|     |_|    \___/  \__,_| \__,_| \___| \__| |_|  |_| \__,_||_| |_| \__,_| \__, | \___||_| |_| |_| \___||_| |_| \__|
                                                                              __/ |                                   
                                                                             |___/                                    ");
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}
