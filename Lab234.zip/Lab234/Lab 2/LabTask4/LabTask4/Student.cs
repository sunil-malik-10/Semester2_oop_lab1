﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabTask4
{
    internal class Student
    {
        public Student()
        {
            Console.WriteLine("Default Constructor Called..");
        }
    }
}
