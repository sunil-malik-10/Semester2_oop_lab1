﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabTask4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student std = new Student();
            Console.Read();
        }
    }
}
