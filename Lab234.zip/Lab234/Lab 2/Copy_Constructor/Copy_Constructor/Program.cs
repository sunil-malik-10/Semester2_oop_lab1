﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Copy_Constructor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student std1 = new Student();
            std1.name = "Named";
            Student std2 = new Student(std1);

            Console.WriteLine(std1.name);
            Console.WriteLine(std2.name);
            Console.WriteLine("End");
            Console.Read();
        }
    }
}
