﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Copy_Constructor
{
    internal class Student
    {
        public Student()
        {
            Console.WriteLine("Default Constructor");
        }
        public Student(Student std)
        {
            name = std.name;
            matricMarks = std.matricMarks;
            fscMarks = std.fscMarks;
            ecatMarks = std.ecatMarks;
        }
        public string name;
        public float matricMarks;
        public float fscMarks;
        public float ecatMarks;
    }
}
