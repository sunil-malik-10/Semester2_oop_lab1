﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SelfAssesment_1__a_
{
    internal class Student
    {
        public Student() {
            name = "Talha";
            matricMarks = 1086;
            fscMarks = 1055;
            ecatMarks = 233;
        }    
        public string name;
        public float matricMarks;
        public float fscMarks;
        public float ecatMarks;
    }
}
