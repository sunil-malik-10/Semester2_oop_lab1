﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SelfAssesment_1__a_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student std = new Student();
            Console.WriteLine(std.name);
            Console.WriteLine(std.matricMarks);
            Console.WriteLine(std.fscMarks);
            Console.WriteLine(std.ecatMarks);
            
            Student std2 = new Student();
            Console.WriteLine(std2.name);
            Console.Read();
        }
    }
}
