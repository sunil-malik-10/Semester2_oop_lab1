﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabTask5
{
    internal class Student
    {
        public Student()
        {
            name = "Joyce";
        }
        public string name;
        public float matricMarks;
    }
}
