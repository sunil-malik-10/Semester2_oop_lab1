﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_2_Tasks
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*int arr_Size = 5;
            string[] snames = new string[arr_Size];
            float[] matricmarks = new float[arr_Size];
            float[] fscMarks = new float[arr_Size];
            float[] ecatMarks = new float[arr_Size];
            float[] aggregate = new float[arr_Size];*/

            Student s1 = new Student();
            s1.sname = "Talha";
            s1.matricMarks = 1086;
            s1.fscMarks = 955;
        }
    }
}
