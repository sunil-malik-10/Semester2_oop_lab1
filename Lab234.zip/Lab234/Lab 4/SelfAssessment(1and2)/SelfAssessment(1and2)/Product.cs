﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SelfAssessment_1and2_
{
    internal class Product
    {
        public string name;
        public string category;
        public int price;

        public Product(string name, string category, int price)
        {
            this.name = name;
            this.category = category;
            this.price = price;
        }

        
    }
}
