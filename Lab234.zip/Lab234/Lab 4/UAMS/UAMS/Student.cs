﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UAMS
{
    internal class Student
    {
        public string name;
        public int age;
        public double fscMarks;
        public double ecatMarks;
        public double merit;
        public List<DegreeProgram> preferences;
        public List<Subject> regSubject;
        public DegreeProgram regDegree;

        public Student (string name, int age, double fscMarks, double ecatMarks,List<DegreeProgram> preferences)
        {
            this.name = name;
            this.age = age;
            this.fscMarks = fscMarks;
            this.ecatMarks = ecatMarks;
            this.preferences = preferences;
            regSubject = new List<Subject>() ;

        }

        public void calculateMerit()
        {
            this.merit = (((fscMarks / 1100) * 0.45F) + ((ecatMarks / 400) * 0.55f)) * 100;
        }

        public bool regStudentSubject(Subject s)
        {
            int stCH = getCreditHours();
            if(regDegree != null && regDegree.isSubjectExists(s) && stCH + s.creditHours <= 9)
            {
                regSubject.Add(s);
                return true;
            }
            else
            {
                return false;
            }
        }

        public int getCreditHours()
        {
            int count = 0;
            foreach(Subject sub in regSubject) 
            {
                count  = count + sub.creditHours;
            }
            return count;
        }

        public float calculateFee()
        {
            float fee = 0;
            if(regDegree != null)
            {
                foreach(Subject sub in regSubject)
                {
                    fee = fee + sub.subjectFees;
                }
            }
            return fee;
        }
    }
}
