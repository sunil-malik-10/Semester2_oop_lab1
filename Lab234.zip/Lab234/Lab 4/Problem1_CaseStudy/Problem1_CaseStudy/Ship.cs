﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem1_CaseStudy
{
    internal class Ship
    {
        public int ShipNumber;
        public Angle Latitude;
        public Angle Longitude;
        public Ship(int shipNumber, Angle latitude, Angle longitude)
        {
            ShipNumber = shipNumber;
            Latitude = latitude;
            Longitude = longitude;
        }
        public void PrintPosition()
        {
            Console.WriteLine($"Latitude: {Latitude.GetAngleString()}, Longitude: {Longitude.GetAngleString()}");
        }
        public void ReportSerialNumber()
        {
            Console.WriteLine($"Ship Number: {ShipNumber}");
        }
    }
}
