﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem1_CaseStudy
{
    internal class Program
    {
        static void Main(string[] args)
        {
            float minAngle;
            int Angle;
            char Direction;
            Console.Write("Enter the Angle (Degrees)");


            Angle latitude = new Angle(17, 31.5f, 'S');
            Angle longitude = new Angle(149, 34.8f, 'W');

            Ship myShip = new Ship(123456, latitude, longitude);

            myShip.PrintPosition();
            myShip.ReportSerialNumber();
            Console.ReadKey();
        }
    }
}
