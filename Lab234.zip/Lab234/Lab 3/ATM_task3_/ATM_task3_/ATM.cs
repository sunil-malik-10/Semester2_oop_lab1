﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATM_task3_
{
    internal class ATM
    {
        public ATM(double bal) 
        {
            balance = bal;
            History = new List<string>();
        }
        
        public void DepositMoney(double m)
        {
            balance += m;
            History.Add("Deposited " + m);
        }
        public void WithdrawMoney(double w)
        {
            balance -= w;
            History.Add("Withdrawn " + w );
        }
        public double CheckBalance()
        {
            return balance;
        }
        public void ShowHistory()
        {
            for(int i = 0; i < History.Count; i++)
            {
                Console.WriteLine(History[i]);
            }
        }
        public double balance;
        List<string> History;
    }
}
