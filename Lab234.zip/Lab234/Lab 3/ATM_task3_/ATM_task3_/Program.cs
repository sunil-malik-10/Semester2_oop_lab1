﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATM_task3_
{
    internal class Program
    {
        static void Main(string[] args) 
        {
            ATM account = new ATM(100);

            Console.Write("Current Balance: "+account.balance + "\n");
            account.DepositMoney(130);
            account.DepositMoney(500);
            Console.Write("Current Balance: " + account.balance + "\n");
            account.WithdrawMoney(100);
            account.WithdrawMoney(20);
            Console.Write("Current Balance: " + account.balance + "\n");
            Console.WriteLine("\nTransaction History ");
            account.ShowHistory();


            int option;
            Console.WriteLine("\n\n\nChoose option: ");
            Console.Write("1.Deposit Money  \n2.Check Balance \n3.Withdraw Money  \n4.Check History \n5.Card Validation\n");
            option = Convert.ToInt32(Console.ReadLine());
            if(option == 1)
            {
                double amount = 0;
                Console.Write("Enter amount : ");
                amount = Convert.ToDouble(Console.ReadLine());
                account.DepositMoney(amount);
                Console.Write("Deposited : " + amount + "\n  New Balance: "+account.balance);
                Console.ReadKey();
            }
            else if(option == 2)
            {
                Console.Write("Available Balance: " + account.balance);
                Console.ReadKey();
            }
            else if(option == 3)
            {
                double amount = 0;
                Console.Write("Enter amount to withdraw: ");
                amount = Convert.ToDouble(Console.ReadLine());
                if(account.balance > 0 || amount <= account.balance)
                {
                    account.WithdrawMoney(amount);
                    Console.Write("Withdrawn: " + amount + "\n  Remaining Balance: "+account.balance);
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("Muaziz Saarif Apka Balance Na kafi hai");
                }
            }
            else if(option == 4) 
            {
                account.ShowHistory();
                Console.ReadKey();
            }


        }
    }
}
