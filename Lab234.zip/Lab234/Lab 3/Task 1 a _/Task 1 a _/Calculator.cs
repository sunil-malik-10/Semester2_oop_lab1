﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_1_a__
{
    internal class Calculator
    {
        public double a;
        public double b;
        public Calculator(double A,double B)
        {
            a = A;
            b = B;
        }
        public double Add()
        {
            return a + b;
        }
        public double Multiply()
        {
            return a * b;
        }
        public double Divide()
        {
            return a / b;
        }
        public double Subtract()
        {
            return a - b;
        }
    }
}
