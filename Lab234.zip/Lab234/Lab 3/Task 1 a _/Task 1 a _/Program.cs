﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_1_a__
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a, b;
            Console.Write("Enter the value of a: ");
            a = double.Parse(Console.ReadLine());
            Console.Write("Enter the value of b: ");
            b = double.Parse(Console.ReadLine());

            Calculator value = new Calculator(a, b);
            Console.Write("Sum: {0} Multiplication: {1} Subtraction: {2} Division: {3}", value.Add(),value.Multiply(),value.Subtract(),value.Divide());
            Console.ReadKey();
        }
    }
}
