﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ooplab2
{
    internal class student
    {
        public student()
        { 
            id = 0;
        }
        public string sname;
        public int id;
        public string name;
        public int age;
        public float ecatmarks; 
    
    }
}
