﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace signupsignin
{
    internal class signup
    {
        public string name;
        public string password;
        public string role;
        
     }
    
}
