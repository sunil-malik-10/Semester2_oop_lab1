﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ooplab2
{
    internal class Program
    {
        static void Main(string[] args) { }
        /*{
            student[] studentdata = new student[5];
            for (int i = 0; i < 5; i++)
            {
                studentdata[i] = takeinput();
            }
            printstudentdata(studentdata);
            Console.ReadKey();
        }
        static student takeinput()
        {
            student s = new student();
            Console.WriteLine("Enter the name: ");
            s.name = Console.ReadLine();
            Console.WriteLine("write the numbers : ");
            s.age = int.Parse(Console.ReadLine());

            return s;
        }
        static void printstudentdata(student[] studentsdata) {
            Console.WriteLine("Name \t numbers");
            for (int i = 0;i < 5;i++) {
                Console.WriteLine(studentsdata[i].name + "\t" + studentsdata[i].age );
            }
                }*/
           /* student n1  = new student();
            n1.sname = "abcd  d d 0";
            n1.id = 1;
            Console.WriteLine("{0}",n1.id);
            Console.ReadKey();*/


           /*student s1 = new student();
            s1.name = "Test";
            Console.WriteLine(s1.id);
            Console.Write(s1.name); 
            Console.Read();*/

        
    }
}
