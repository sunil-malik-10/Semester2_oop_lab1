﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPselfassesment1b
{
    internal class student
    { 
        public int id;
        public string name;
        public int age = 12;
        public float marks;    
    }
}
