﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPselfassesment
{
    internal class student
    {
        public string name;
        public int age;
        public float marks;
        public char grade;
    }
}
